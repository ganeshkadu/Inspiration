//
//  AppDelegate.h
//  MaterialDesignDemo
//
//  Created by ganesh on 22/05/18.
//  Copyright © 2018 ganesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

