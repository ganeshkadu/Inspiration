//
//  ViewController.h
//  MaterialDesignDemo
//
//  Created by ganesh on 22/05/18.
//  Copyright © 2018 ganesh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MaterialButtons.h"
#import "MaterialButtons+ButtonThemer.h"

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet MDCButton *btnTest;



@end

