//
//  ViewController.m
//  MaterialDesignDemo
//
//  Created by ganesh on 22/05/18.
//  Copyright © 2018 ganesh. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    MDCButton *button = [[MDCButton alloc] init];
    MDCButtonScheme *buttonScheme = [[MDCButtonScheme alloc] init];
    
    // Themed as a text button:
  [MDCTextButtonThemer applyScheme:buttonScheme toButton:button];
    [MDCOutlinedButtonThemer applyScheme:buttonScheme toButton:button];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
